package model;

public enum Status {
    PASS,
    FAILED
}
